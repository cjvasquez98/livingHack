<script type="text/javascript">
      function abrir(){
          window.open("formulario-denuncia.html");
      }     
            jQuery(window).load(function(){
                jQuery("#status").fadeOut();
         jQuery("#preloader").delay(1000).fadeOut("slow");
            })
        </script>